import logo from './logo.svg';
import './App.css';
import AllRoute from './Component/Allroute';

function App() {
  return (
    <div className="App">
      <AllRoute/>
    </div>
  );
}

export default App;
